﻿using static CrudOperations.Dtos;
namespace CrudOperations
{
    public static class Extensions
    {
        public static UserDto AsDto(this Users usr)
        {
            return new UserDto(usr.Id, usr.Name, usr.Age, usr.CreatedTime);
        }
    }
}
