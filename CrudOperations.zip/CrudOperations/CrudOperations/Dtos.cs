﻿namespace CrudOperations
{
    public class Dtos
    {
        public record UserDto(Guid Id,string Name, int Age, DateTime CreatedTime);
        public record PostUserDto(Guid Id,string Name, int Age, DateTime CreatedTime);
    }
    
}
