﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MySql.Data.MySqlClient;
using static CrudOperations.Dtos;

namespace CrudOperations.Controllers
{
    [Route("users")]
    [ApiController]
    public class UsersController : ControllerBase
    {
        Connect c = new();
        [HttpGet]
        public string Get()
        {
            try
            {
                
                return "Sikeres csatlakozás";
            }
            catch (Exception e)
            {
                return e.Message;
            }
        }

        [HttpPost]
        public ActionResult<string> Post(PostUserDto createUser)
        {
            string sql = "INSERT INTO `usr`(`Id`,`Name`, `Age`, `CreatedTime`) VALUES (@Id,@Name,@Age,@CreatedTime)";

            MySqlCommand cmd= new MySqlCommand(sql, c.conn);

            cmd.Parameters.AddWithValue("Id", Guid.NewGuid());
            cmd.Parameters.AddWithValue("Name", createUser.Name);
            cmd.Parameters.AddWithValue("Age", createUser.Age);
            cmd.Parameters.AddWithValue("CreatedTime", DateTime.Now);

            cmd.ExecuteNonQuery();
            return StatusCode(201, "Új record felvéve.");
        }
    }
}
