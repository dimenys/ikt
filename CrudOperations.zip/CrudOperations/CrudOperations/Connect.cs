﻿using MySql.Data.MySqlClient;
namespace CrudOperations

{
    public class Connect
    {



        public MySqlConnection conn;

        string Host = "192.168.50.103";
        string Db = "Users";
        string Uid = "root";
        string Pass = "password";

        public Connect()
        {
                String connectionString = $"SERVER={Host};" + $"DATABASE={Db};" + $"UID={Uid};" + $"PASSWORD={Pass};" + "SSL MODE=none;";

                conn = new MySqlConnection(connectionString);
                
                conn.Open();
        }
    }
}
